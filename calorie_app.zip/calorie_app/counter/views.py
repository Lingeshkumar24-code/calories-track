from django.shortcuts import render
#p400j7viNHLsSa3ygZ9MjA==xMhGyTufBcA7GPb9

def home(request):
    import json
    import requests
    if request.method =='POST':
        query = request.POST['query']
        api_url = 'https://api.calorieninjas.com/v1/nutrition?query='
        api_request = requests.get (api_url + query, headers ={'X-api-Key': 'p400j7viNHLsSa3ygZ9MjA==xMhGyTufBcA7GPb9'})
        try :
            api= json.loads(api_request.content)
            print(api_request.content)
        except Exception as e:
            api= "oops! there was an error"
            print(e)
        return render(request,'home.html', {"api": api["items"]})
    else:
        return render(request,'home.html',{'query':'enter a valid query'})

    